document.addEventListener('DOMContentLoaded', () => {
    // 1. Inject the Lightbox HTML structure dynamically
    const overlay = document.createElement('div');
    overlay.className = 'lightbox-overlay';
    
    const img = document.createElement('img');
    img.className = 'lightbox-image';
    
    const closeBtn = document.createElement('div');
    closeBtn.className = 'lightbox-close';
    closeBtn.innerHTML = '&times;'; // HTML entity for 'X'
    
    overlay.appendChild(img);
    overlay.appendChild(closeBtn);
    document.body.appendChild(overlay);

    // 2. Variable to hold the timer
    let hoverTimer;
    const hoverDelay = 1000; // CHANGED: 1000ms = 1 second

    // 3. Select all images on the page
    const images = document.querySelectorAll('img');

    images.forEach(image => {
        // Logic for Mouse Enter
        image.addEventListener('mouseenter', () => {
            image.style.cursor = 'zoom-in'; // Visual cue for user
            
            // Start the 1-second countdown
            hoverTimer = setTimeout(() => {
                openLightbox(image.src);
            }, hoverDelay);
        });

        // Logic for Mouse Leave
        image.addEventListener('mouseleave', () => {
            // If mouse leaves before 1s, cancel the timer
            clearTimeout(hoverTimer);
            image.style.cursor = 'default';
        });
    });

    // 4. Function to open the lightbox
    function openLightbox(src) {
        img.src = src;
        overlay.classList.add('active');
    }

    // 5. Function to close the lightbox
    function closeLightbox() {
        overlay.classList.remove('active');
        // Clear source after animation to prevent flicker
        setTimeout(() => { img.src = ''; }, 300);
    }

    // Event listeners for closing
    closeBtn.addEventListener('click', closeLightbox);
    
    // Close if clicking outside the image (on the dark background)
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            closeLightbox();
        }
    });

    // Close on ESC key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && overlay.classList.contains('active')) {
            closeLightbox();
        }
    });
});